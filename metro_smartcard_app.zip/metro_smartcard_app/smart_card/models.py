from django.db import models


# Create your models here.

class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    user_name = models.CharField(max_length=50)
    password = models.CharField(max_length=15)
    email = models.EmailField(max_length=50)
    phone_number = models.BigIntegerField()
    created_date = models.DateTimeField(auto_now_add=True)


class Card_Details(models.Model):
    card_id = models.AutoField(primary_key=True)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    buy_date = models.DateTimeField(auto_now_add=True)
    total_blc = models.DecimalField(decimal_places=2, max_digits=10)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        saved_instance = Card_Details.objects.get(pk=self.pk)
        return saved_instance


class Topup_Details(models.Model):
    topup = models.AutoField(primary_key=True)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    card_id = models.ForeignKey(Card_Details, on_delete=models.CASCADE)
    topup_amount = models.DecimalField(decimal_places=2, max_digits=65)
    card_total_amount = models.DecimalField(decimal_places=2, max_digits=65)
    topup_date = models.DateTimeField(auto_now_add=True)


class Stations(models.Model):
    id = models.AutoField(primary_key=True)
    source_loc = models.CharField(max_length=50)
    destination_loc = models.CharField(max_length=50)
    no_of_stations = models.IntegerField()


class Transaction_Details(models.Model):
    trans_id = models.AutoField(primary_key=True)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    station_id = models.ForeignKey(Stations, on_delete=models.CASCADE)
    travel_amt = models.DecimalField(decimal_places=2, max_digits=65)
    available_blc = models.DecimalField(decimal_places=2, max_digits=65)
    date_of_travel = models.DateTimeField(auto_now_add=True)
    created_date = models.DateTimeField(auto_now_add=True)
    stations_travelled = models.IntegerField()
    journey_status = models.CharField(max_length=50)
    discount_status = models.CharField(max_length=10)
