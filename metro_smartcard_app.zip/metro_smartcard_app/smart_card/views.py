from django.contrib.auth import logout
from django.db import connection
from django.db.models import Max, Sum, Q
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from decimal import Decimal

from .models import User, Card_Details, Topup_Details, Stations, Transaction_Details


# Create your views here.
@csrf_exempt
def register_user(request):
    if request.method == 'POST' and list(request.POST.keys()).__contains__('register'):
        user_data = request.POST
        user = User(user_name=user_data['UserName'], password=user_data['Password'],
                    email=user_data['Email'], phone_number=user_data['PhoneNumber'])
        user.save()
        user_obj = User.objects.filter(email=user_data['Email'])
        return user_data['UserName'], user_obj


@csrf_exempt
def index(request):
    request.session['user_refresh'] = False
    if list(request.POST.keys()).__contains__('topup') and request.POST.keys() is not None:
        topup_card(request)
        context = station_details(request)
        user_exist_refresh = False
        if request.session.get('user_data') is not None:
            user_exist_refresh = True
        return render(request, template_name='main.html',
                      context={'station_context': context, 'user_info': request.session.get('user_data'),
                               'user_exist_refresh': user_exist_refresh, 'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'),
                               'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})
    elif list(request.POST.keys()).__contains__('card') and request.POST.keys() is not None:
        buy_a_card(request)
        user_exist_refresh = False
        if request.session.get('user_data') is not None:
            user_exist_refresh = True
        context = station_details(request)
        return render(request, template_name='main.html',
                      context={'station_context': context, 'user_info': request.session.get('user_data'),
                               'user_exist_refresh': user_exist_refresh, 'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'),
                               'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})
    elif list(request.POST.keys()).__contains__('journey') and request.POST.keys() is not None:
        dest_loc_list = start_journey(request)
        user_exist_refresh = False
        refresh = False
        if request.session.get('user_data') is not None:
            user_exist_refresh = True
            Inprogress_Trans = Transaction_Details.objects.filter(
                Q(journey_status="InProgress") & Q(user_id=request.session.get('user_obj')))
            Inprogress_Trans_count = Inprogress_Trans.count()
            card_info_check = Card_Details.objects.filter(user_id=request.session.get('user_obj'))
            if card_info_check.exists() and Decimal(request.session.get('card_balance')) >= 15 and Inprogress_Trans_count == 0:
                refresh = True
        return render(request, template_name='main.html',
                      context={'refresh': refresh, 'message': dest_loc_list,
                               'user_info': request.session.get('user_data'),
                               'user_exist_refresh': user_exist_refresh, 'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'),
                               'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})
    elif list(request.POST.keys()).__contains__('logout') and request.POST.keys() is not None:
        user_exist_refresh = False
        logout(request)
        request.session.flush()
        return render(request, template_name='register.html',
                      context={'user_info': request.session.get('user_data'), 'user_exist_refresh': user_exist_refresh,
                               'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'),
                               'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})
    elif list(request.POST.keys()).__contains__('transcations') and request.POST.keys() is not None:
        user_exist_refresh = True
        topupTran, trans_data = transcations(request)
        return render(request, template_name='transcations.html',
                      context={'user_info': request.session.get('user_data'), 'user_exist_refresh': user_exist_refresh,
                               'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'), 'topup': topupTran,
                               'trans_data': trans_data, 'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})
    elif list(request.POST.keys()).__contains__('backbutton') and request.POST.keys() is not None:
        user_exist_refresh = True
        context = station_details(request)
        return render(request, template_name='main.html',
                      context={'station_context': context, 'user_info': request.session.get('user_data'),
                               'user_exist_refresh': user_exist_refresh, 'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'),
                               'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})
    else:
        data = request.body
        user_exist_refresh = False
        if request.session.get('user_data') is not None:
            user_exist_refresh = True
        decoded_string = data.decode('utf-8')
        decoded_string = decoded_string.replace("{", "")
        decoded_string = decoded_string.replace("}", "")
        decoded_string = decoded_string.replace('"', "")
        decoded_string = decoded_string.replace('key2', "")
        decoded_string = decoded_string.replace('key3', "")
        decoded_string = decoded_string.replace(',', "")
        decoded_string = decoded_string.split(":")

        if decoded_string[0] != '':
            intial_number = int(decoded_string[1])
            final_number = int(decoded_string[len(decoded_string) - 1]) - 1
            if intial_number == final_number:
                end_journey(request, decoded_string[len(decoded_string) - 2])
        context = station_details(request)
        return render(request, template_name='main.html',
                      context={'station_context': context, 'user_info': request.session.get('user_data'),
                               'user_exist_refresh': user_exist_refresh, 'card_id': request.session.get('card_id'),
                               'card_balance': request.session.get('card_balance'),
                               'user_message': request.session.get('message'),
                               'user_refresh': request.session.get('user_refresh')})


@csrf_exempt
def registerloginbutton(request):
    request.session['user_refresh'] = False
    if list(request.POST.keys()).__contains__('login') and request.POST.keys() is not None:
        message, user_info = login(request)
        context = station_details(request)
        if message == 'login success':
            user_context = user_info[0]
            request.session['user_data'] = user_context.user_name
            request.session['user_obj'] = user_context.user_id
            card_info = Card_Details.objects.filter(user_id=user_context.user_id)
            if card_info.exists():
                request.session['card_id'] = str(card_info[0].card_id)
                request.session['card_balance'] = str(card_info[0].total_blc)
            else:
                request.session['card_id'] = 'N/A'
                request.session['card_balance'] = str(0)
            return redirect("/index")
        elif message == 'please check the password':
            return render(request, template_name='register.html',
                          context={'station_context': context, 'user_message': request.session.get('message'),
                                   'user_refresh': request.session.get('user_refresh')})
        elif message == 'please register or check your email':
            return render(request, template_name='register.html',
                          context={'station_context': context, 'user_message': request.session.get('message'),
                                   'user_refresh': request.session.get('user_refresh')})
        else:
            return render(request, template_name='register.html',
                          context={'station_context': context, 'user_message': request.session.get('message'),
                                   'user_refresh': request.session.get('user_refresh')})
    elif list(request.POST.keys()).__contains__('register') and request.POST.keys() is not None:
        user_info, user_obj = register_user(request)
        context = station_details(request)
        print(user_obj)
        request.session['user_obj'] = user_obj[0].user_id
        request.session['user_data'] = user_obj[0].user_name
        # return redirect("/index")
        return render(request, template_name='main.html', context={'user_refresh': request.session.get('user_refresh'),
                                                                   'station_context': context,
                                                                   'user_exist_refresh': True,
                                                                   'user_info': user_info,
                                                                   'card_id': 'N/A',
                                                                   'card_balance': 0,
                                                                   'user_message': request.session.get('message')})

    else:
        return render(request, template_name='register.html', context={'user_message': request.session.get('message'),
                                                                       'user_refresh': request.session.get(
                                                                           'user_refresh')})


@csrf_exempt
def topup_card(request):
    if request.method == 'POST':
        topup_data = request.POST
        topup_user = User.objects.filter(email=topup_data['userInfo'])
        if topup_user.exists():
            card_info = Card_Details.objects.filter(user_id=topup_user[0].user_id)
            if card_info.exists():
                card_info_old = Card_Details.objects.filter(user_id=request.session.get('user_obj'))
                if card_info_old.exists():
                    request.session['card_id'] = Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].card_id
                else:
                    request.session['card_id'] = 'N/A'
                Inprogress_Trans = Transaction_Details.objects.filter(
                    Q(journey_status="InProgress") & Q(user_id=topup_user[0].user_id))
                Inprogress_Trans_count = Inprogress_Trans.count()
                if Inprogress_Trans_count == 0:
                    card_total_amt = Topup_Details.objects.values('user_id', 'card_id').annotate(
                        max_count=Max('card_total_amount')).filter(user_id=topup_user[0].user_id)
                    topup_value = Topup_Details(user_id=topup_user[0], card_id=card_info[0],
                                                topup_amount=int(topup_data['topupAmt']),
                                                card_total_amount=int(topup_data['topupAmt']) + card_total_amt[0][
                                                    'max_count'])
                    topup_value.save()
                    sum_travelled = Transaction_Details.objects.values('user_id', 'journey_status').annotate(
                        sum_amount=Sum('travel_amt')).filter(journey_status="Completed", user_id=topup_user[0].user_id)
                    # (sum_travelled)
                    total_amount = card_total_amt[0]['max_count']
                    user_id_value = topup_user[0].user_id
                    if sum_travelled.exists():
                        Card_Details.objects.filter(user_id=user_id_value).update(
                            total_blc=(total_amount - sum_travelled[0]['sum_amount']))
                        if card_info_old.exists():
                            request.session['card_balance'] = \
                            str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].total_blc)
                        else:
                            request.session['card_balance'] = '0'
                        #request.session['card_balance'] = str((total_amount - sum_travelled[0]['sum_amount']))
                    else:
                        Card_Details.objects.filter(user_id=user_id_value).update(total_blc=total_amount)
                        if card_info_old.exists():
                            request.session['card_balance'] = \
                                str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].total_blc)
                        else:
                            request.session['card_balance'] = '0'
                else:
                    min_topup_amt = Inprogress_Trans[0].travel_amt
                    if int(topup_data['topupAmt']) >= int(min_topup_amt):
                        request.session['user_refresh'] = True
                        request.session['message'] = "Thanks for using the Metro,Your Previous Journey is Completed"
                        card_total_amt = Topup_Details.objects.values('user_id', 'card_id').annotate(
                            max_count=Max('card_total_amount')).filter(user_id=topup_user[0].user_id)
                        topup_value = Topup_Details(user_id=topup_user[0], card_id=card_info[0],
                                                    topup_amount=int(topup_data['topupAmt']),
                                                    card_total_amount=int(topup_data['topupAmt']) + card_total_amt[0][
                                                        'max_count'])
                        topup_value.save()
                        sum_travelled = Transaction_Details.objects.values('user_id', 'journey_status').annotate(
                            sum_amount=Sum('travel_amt')).filter(journey_status="Completed",
                                                                 user_id=topup_user[0].user_id)
                        # (sum_travelled)
                        total_amount = card_total_amt[0]['max_count']
                        user_id_value = topup_user[0].user_id
                        if sum_travelled.exists():
                            Card_Details.objects.filter(user_id=user_id_value).update(
                                total_blc=(total_amount - sum_travelled[0]['sum_amount']))
                            if card_info_old.exists():
                                request.session['card_balance'] = \
                                    str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].total_blc)
                            else:
                                request.session['card_balance'] = '0'
                        else:
                            Card_Details.objects.filter(user_id=user_id_value).update(total_blc=total_amount)
                            if card_info_old.exists():
                                request.session['card_balance'] = \
                                    str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].total_blc)
                            else:
                                request.session['card_balance'] = '0'
                        card_info_new = Card_Details.objects.filter(user_id=topup_user[0].user_id)
                        current_available_blc = card_info_new[0].total_blc - Inprogress_Trans[0].travel_amt
                        Transaction_Details.objects.filter(trans_id=Inprogress_Trans[0].trans_id).update(
                            available_blc=current_available_blc, journey_status="Completed")
                        Card_Details.objects.filter(user_id=topup_user[0].user_id).update(
                            total_blc=current_available_blc)
                        if card_info_old.exists():
                            request.session['card_balance'] = \
                                str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].total_blc)
                        else:
                            request.session['card_balance'] = '0'
                    else:
                        request.session['user_refresh'] = True
                        request.session['message'] = "ReCharge your Card with Minimum Amount of " + str(
                            min_topup_amt) + " and Exit the Station"
            else:
                request.session['user_refresh'] = True
                request.session['message'] = "Please buy a card"

        else:
            request.session['user_refresh'] = True
            request.session['message'] = "Please register"


@csrf_exempt
def buy_a_card(request):
    if request.method == 'POST':
        card_data = request.POST
        user_info = User.objects.filter(email=card_data['userInfo'])
        if user_info.exists():
            card_info = Card_Details.objects.filter(user_id=user_info[0].user_id)
            if card_info.exists():
                request.session['user_refresh'] = True
                request.session['message'] = 'Card already exists'
                card_info_old = Card_Details.objects.filter(user_id=request.session.get('user_obj'))
                if card_info_old.exists():
                    request.session['card_id'] = Card_Details.objects.filter(user_id=request.session.get('user_obj'))[
                        0].card_id
                else:
                    request.session['card_id'] = 'N/A'
            else:
                card = Card_Details(user_id=user_info[0], total_blc=25)
                card_obj = card.save()
                topup = Topup_Details(topup_amount=25, card_total_amount=25, user_id=user_info[0],
                                      card_id=card_obj)

                topup.save()
                #request.session['card_balance'] = str(25)
                #request.session['card_id'] = card_obj.card_id
                card_info_old = Card_Details.objects.filter(user_id=request.session.get('user_obj'))
                if card_info_old.exists():
                    request.session['card_id'] = Card_Details.objects.filter(user_id=request.session.get('user_obj'))[
                        0].card_id
                    request.session['card_balance'] = str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[
                        0].total_blc)
                else:
                    request.session['card_id'] = 'N/A'
                    request.session['card_balance'] = '0'
                request.session['user_refresh'] = True
                request.session['message'] = "Thanks for Buying the Card "+str(card_obj.card_id)+" and Have a Happy Journey"
        else:
            request.session['user_refresh'] = True
            request.session['message'] = "Please register"


def station_details(request):
    sources = Stations.objects.values('source_loc').distinct()
    data = {'sources': sources}
    return data


def start_journey(request):
    request.session['source_loc'] = request.POST['sourcelocation']
    dest_loc = Stations.objects.filter(source_loc=request.POST['sourcelocation'])
    dest_loc_list = []
    dest_loc_list.append("Be Ready to Board the Train at " + request.POST['sourcelocation'])
    dest_loc_list.append("Train Will Start in 5 Seconds")
    for dest in dest_loc:
        dest_loc_list.append("Your Train Next Station is: " + dest.destination_loc)
    dest_loc_list.append("Thanks for Choosing the Metro Service")
    user_info = User.objects.filter(user_id=request.session.get('user_obj'))
    if user_info.exists():
        card_info = Card_Details.objects.filter(user_id=user_info[0].user_id)
        if card_info.exists():
            card_blc = card_info[0].total_blc
            card_info_old = Card_Details.objects.filter(user_id=request.session.get('user_obj'))
            if card_info_old.exists():
                request.session['card_id'] = Card_Details.objects.filter(user_id=request.session.get('user_obj'))[
                    0].card_id
            else:
                request.session['card_id'] = 'N/A'
            Inprogress_Trans = Transaction_Details.objects.filter(
                Q(journey_status="InProgress") & Q(user_id=user_info[0].user_id))
            Inprogress_Trans_count = Inprogress_Trans.count()
            if card_blc >= 15 and Inprogress_Trans_count == 0:
                request.session['user_refresh'] = True
                request.session['message'] = "Start journey"
            elif Inprogress_Trans_count>0:
                request.session['user_refresh'] = True
                request.session['message'] = "Please Complete the Previous Journey By adding the Topup Amount"
            else:
                request.session['user_refresh'] = True
                request.session['message'] = "Please recharge your card with atleast Rs.15 to Start the Journey"

        else:
            request.session['user_refresh'] = True
            request.session['message'] = "Please purchase the card"
    else:
        request.session['user_refresh'] = True
        request.session['message'] = "Please login to start the journey"
    return dest_loc_list


def login(request):
    user_data = request.POST
    user_info = User.objects.filter(email=user_data['email'])
    if user_info.exists():
        if user_info[0].password == user_data['password']:
            request.session['user_refresh'] = True
            request.session['message'] = "Login success"
            return "login success", user_info
        elif user_info[0].password != user_data['password']:
            request.session['user_refresh'] = True
            request.session['message'] = "Please check the password"
            return "please check the password", ""
    else:
        request.session['user_refresh'] = True
        request.session['message'] = "Please register or check your email"
        return "please register or check your email", ""


def transcations(request):
    topupTran = Topup_Details.objects.filter(user_id=request.session.get('user_obj')).order_by('-topup_date')[:5]
    # data = {'topup': topupTran}
    user_info = User.objects.filter(user_id=request.session.get('user_obj'))
    query = "select t.trans_id,t.available_blc,t.journey_status,s.source_loc,s.destination_loc,t.stations_travelled," \
            "t.travel_amt," \
            "t.discount_status,t.date_of_travel from metro_smart_card.smart_card_transaction_details t join " \
            "metro_smart_card.smart_card_stations s on (s.id=t.station_id_id) where t.user_id_id =%s order by " \
            "date_of_travel desc limit 6"
    params = [user_info[0].user_id]
    trans_data = ''
    with connection.cursor() as cursor:
        cursor.execute(query, params)
        columns = [col[0] for col in cursor.description]
        trans_data = cursor.fetchall()
    queryset = [dict(zip(columns, row)) for row in trans_data]
    # trans_data = Transaction_Details.objects.filter(user_id=request.session.get('user_obj')).order_by('-created_date')[:5]
    return topupTran, queryset


def end_journey(request, dest_loc):
    source_loc = request.session.get('source_loc')
    dest_loc = dest_loc.replace(" ", "")
    
    number_of_stations_obj = Stations.objects.filter(Q(source_loc=source_loc) & Q(destination_loc=dest_loc))
    number_of_stations = number_of_stations_obj[0].no_of_stations
    user_info = User.objects.filter(user_id=request.session.get('user_obj'))
    card_info = Card_Details.objects.filter(user_id=user_info[0].user_id)
    amount_charged = number_of_stations * 5
    total_stations_travel = Transaction_Details.objects.values('user_id').annotate(
        sum_stations=Sum('stations_travelled'))
    discount_status = ''
    total_amt_charged = int(card_info[0].total_blc) - int(amount_charged)
    #print(int(card_info[0].total_blc))
    #print(total_amt_charged)
    if total_amt_charged < 0:
        trans_check=False
    else:
        trans_check = True
    if trans_check:
        if discount_check(number_of_stations, user_info[0].user_id):
            discount_status = 'Y'
            amount_charged = amount_charged - (amount_charged * 0.05)
        transcation = Transaction_Details(travel_amt=amount_charged,
                                          available_blc=(card_info[0].total_blc - Decimal(amount_charged)),
                                          stations_travelled=number_of_stations, journey_status="Completed",
                                          station_id=number_of_stations_obj[0], user_id=user_info[0],
                                          discount_status=discount_status)
        transcation.save()
        Card_Details.objects.filter(user_id=user_info[0].user_id).update(
            total_blc=(card_info[0].total_blc - Decimal(amount_charged)))
        card_info = Card_Details.objects.filter(user_id=user_info[0].user_id)
        card_info_old = Card_Details.objects.filter(user_id=request.session.get('user_obj'))
        if card_info_old.exists():
            request.session['card_balance'] = \
                str(Card_Details.objects.filter(user_id=request.session.get('user_obj'))[0].total_blc)
        else:
            request.session['card_balance'] = '0'
    else:
        request.session['user_refresh'] = True
        request.session['message'] = "ReCharge your Card with Minimum Amount of " + str(
            amount_charged) + " and Exit the Station"
        if discount_check(number_of_stations, user_info[0].user_id):
            discount_status = 'Y'
            amount_charged = amount_charged - (amount_charged * 0.05)
        transcation = Transaction_Details(travel_amt=amount_charged,
                                          available_blc=(card_info[0].total_blc - Decimal(amount_charged)),
                                          stations_travelled=number_of_stations, journey_status="InProgress",
                                          station_id=number_of_stations_obj[0], user_id=user_info[0],
                                          discount_status=discount_status)
        transcation.save()


def discount_check(stations_travelled, user_id):
    query = "select sum(stations_travelled) from metro_smart_card.smart_card_transaction_details where trans_id>(" \
            "SELECT MAX(trans_id) FROM metro_smart_card.smart_card_transaction_details where discount_status='Y' and " \
            "user_id_id=%s order by date_of_travel) and user_id_id=%s group by user_id_id"
    params = [user_id, user_id]
    results = ''
    total_stations = 0
    with connection.cursor() as cursor:
        cursor.execute(query, params)
        results = cursor.fetchall()
    if len(results) != 0:
        total_stations = stations_travelled + int(results[0][0])
    else:
        total_stations = stations_travelled

    if total_stations >= 5:
        return True
    else:
        return False
