from django.urls import path

from . import views
from .views import register_user, index, registerloginbutton, station_details, transcations

urlpatterns = [
    path('index/', index, name='index'),
    path('index/register/', registerloginbutton, name='registerloginbutton'),
    path('index/transcations/', transcations, name='transcations')
]