var buttonTitles = ["Button 1", "Button 2", "Button 3", "Button 4", "Button 5"]; // Add more button titles as needed
var currentIndex = 0;

function createButtons() {
  var buttonList = document.getElementById('button-list');
  buttonList.innerHTML = ""; // Clear existing buttons

  for (var i = 0; i < buttonTitles.length; i++) {
    var li = document.createElement('li');
    var a = document.createElement('a');
    a.href = "#";
    a.textContent = buttonTitles[i];
    li.appendChild(a);
    buttonList.appendChild(li);
  }
}

function changeButtons() {
  currentIndex = (currentIndex + 1) % buttonTitles.length;
  var buttonList = document.getElementById('button-list');
  var buttons = buttonList.getElementsByTagName('li');

  for (var i = 0; i < buttons.length; i++) {
    buttons[i].getElementsByTagName('a')[0].textContent = buttonTitles[(currentIndex + i) % buttonTitles.length];
  }
}

// Initial setup
createButtons();
setInterval(changeButtons, 5000); // Change buttons every 5 seconds
